Instructions to Setting:
1.	Click on above download button or Link below:
- MBTrade : https://indicators.currenttech.pro/download/MB28Trade.zip
2. Extract zip Files 
3. Open TradeHall MT5, go to File – Open Data Folder 
4. Double click to open “MQL5” folder and then "Experts" folder
5. Copy MB_Trade.ex5 put into this folder 
6. After that go back your TradeHall MT5, on Navigator looking for Expert Advisors right click Refresh 
7. Double click [MB_Trade.ex5], and then input serial number 
8. Enjoy it 